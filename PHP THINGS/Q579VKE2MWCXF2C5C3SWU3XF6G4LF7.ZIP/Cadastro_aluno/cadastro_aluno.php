<html>
  <head>
    <title>Sistema de Cadastro de Turmas e Alunos</title>
    <meta charset="UTF-8">
  </head>
  <body>
    <h1>Cadastro de Alunos</h1>
    <form  action="incluir_aluno.php" method="POST">
      <p>RA: <input type="text" name="ra" /></p>
      <p>Nome: <input type="text" name="nome" /></p>
      <p>Telefone: <input type="text" name="telefone" /></p>
      <p>Turma: <input type="text" name="turma" /></p>
      <p><input value="Salvar" type="submit" /></p>
    </form>
  </body>
</html>  
