<html>
  <head>
    <title>Sistema de Cadastro de Turmas e Alunos</title>
    <meta charset="UTF-8">
  </head>
  <body>
    <h1>Cadastro de Turmas</h1>
    <form  action="incluir_turma.php" method="POST">
      <p>Código: <input type="text" name="codigo" /></p>
      <p>Curso: <input type="text" name="curso" /></p>
      <p>Semestre: <input type="text" name="semestre" /></p>
      <p>Ano: <input type="text" name="ano" /></p>
      <p><input value="Salvar" type="submit" /></p>
    </form>
  </body>
</html>  

