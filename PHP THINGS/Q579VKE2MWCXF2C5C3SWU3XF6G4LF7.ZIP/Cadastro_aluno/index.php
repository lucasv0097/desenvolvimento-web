<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title>Sistema de Cadastro de Turmas e Alunos</title>
    </head>
    <body>
        <h1>Sistema de Cadastro de Turmas e Alunos</h1>
        
	<a href="relacao_turma.php">Turma</a><br />
        <a href="relacao_aluno.php">Alunos</a><br />

    </body>
</html>
